//
//  DetailViewController.swift
//  DetailViewApp
//
//  Created by Yuvaraj Mayank Konjeti on 25/10/2023.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailLabel: UILabel!
    var detailValue: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        detailLabel.text = detailValue
    }
    
    @IBAction func onTapDismiss(_ sender: Any) {
        performSegue(
            withIdentifier: "backToMainController",
            sender: self
        )
    }
}
