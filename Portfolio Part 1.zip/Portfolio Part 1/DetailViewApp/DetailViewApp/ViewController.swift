//
//  ViewController.swift
//  DetailViewApp
//
//  Created by Yuvaraj Mayank Konjeti on 25/10/2023.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var listTableView: UITableView!
    
    var fruits = ["Banana", "Orange", "Apple", "Mango"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        listTableView.delegate = self
        listTableView.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // helps to pass the data
        if let cell = sender as? UITableViewCell {
            let i = self.listTableView.indexPath(for: cell)!.row
            if segue.identifier == "detailSegue" {
                let vc = segue.destination as! DetailViewController
                vc.detailValue = fruits[i]
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fruits.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        // setting indicator
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = fruits[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        tableView.deselectRow(at: indexPath, animated: true)
        
        // trigs to detail ViewController
        performSegue(withIdentifier: "detailSegue", sender: cell)
        
        
    }
    
    // calls when coming from detail view
    @IBAction func unwindToMain(segue: UIStoryboardSegue) { }
    
}

