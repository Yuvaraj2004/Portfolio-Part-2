//
//  ViewController.swift
//  TableViewApp
//
//  Created by Yuvaraj Mayank Konjeti on 25/10/2023.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var numberTextField: UITextField!
    @IBOutlet weak var tablesTableView: UITableView!
    
    @IBOutlet weak var goButton: UIButton!
    
    private let numberOfRows = 30
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tablesTableView.delegate = self
        self.tablesTableView.dataSource = self
        
        self.numberTextField.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // hide the table view and disable the 'Go' button on app init
        tablesTableView.isHidden = true
        goButton.isEnabled = false
        goButton.alpha = 0.5
    }
    
    @IBAction func goAct(_ sender: Any) {
        // dismiss keyboard and show tableview
        numberTextField.resignFirstResponder()
        tablesTableView.isHidden = false
        tablesTableView.reloadData()
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let inputValue = numberTextField.text!
        
        switch indexPath.section {
        case 0: // multiply section
            let value = (indexPath.row + 1) * (Int(inputValue) ?? 1)
            let textValue = "\(indexPath.row + 1) X \(inputValue) = \(value)"
            cell.textLabel?.text = textValue
            
            return cell
        case 1: // division section
            let value = (Double(inputValue) ?? 1.0) / Double(indexPath.row + 1)
            let textValue = "\(inputValue) / \(indexPath.row + 1) = \(String(format: "%.4f", value))"
            
            cell.textLabel?.text = textValue
            
            return cell
        default: break
        }
        
        return UITableViewCell()
        
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return "MULTIPLY"
        case 1: return "DIVISION"
        default: return ""
        }
    }
    
    // [HELPER dynamic - hiding tableView and disable button]
    // referred from below link
    // https://matovsky.com/how-disable-button-if-textfield-empty-swift-4.html
    
    func textField(
        _ textField: UITextField,
        shouldChangeCharactersIn range: NSRange,
        replacementString string: String) -> Bool {
            let text = (numberTextField.text! as NSString).replacingCharacters(in: range, with: string)
            
            if text.isEmpty {
                tablesTableView.isHidden = true
                goButton.isEnabled = false
                goButton.alpha = 0.5
            } else {
                tablesTableView.isHidden = true
                goButton.isEnabled = true
                goButton.alpha = 1.0
            }
            return true
        }
}

